import csv
import io
from datetime import date, timedelta

import requests
from flask import (
    Blueprint, render_template, redirect, url_for, flash, request, jsonify, Response
)
from flask_login import login_required, current_user

from app import db
from app.models import Farm, PluckingRecord, PruningRecord, Tool, Note

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def landing():
    return render_template("landing.html")


@main_bp.route("/terms")
def terms():
    return render_template("terms.html", updated_date=date.today().strftime("%d %B %Y"))


def _get_selected_farm():
    farm_id = request.args.get("farm_id", type=int)
    farms = current_user.farms
    if not farms:
        return None
    if farm_id:
        for f in farms:
            if f.id == farm_id:
                return f
    return farms[0]


def _get_weather():
    try:
        resp = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": -0.3676,
                "longitude": 35.2836,
                "current": "temperature_2m,precipitation,weather_code",
                "daily": "precipitation_sum,temperature_2m_max,temperature_2m_min",
                "timezone": "Africa/Nairobi",
                "forecast_days": 3,
            },
            timeout=4,
        )
        if resp.ok:
            return resp.json()
    except requests.RequestException:
        pass
    return None


@main_bp.route("/dashboard")
@login_required
def dashboard():
    farm = _get_selected_farm()
    farms = current_user.farms

    plucking_records, pruning_records, tools, recent_notes = [], [], [], []
    total_kilos, avg_daily, last_30_kilos = 0, 0, 0
    chart_labels, chart_values = [], []

    if farm:
        plucking_records = (
            PluckingRecord.query.filter_by(farm_id=farm.id)
            .order_by(PluckingRecord.date.desc())
            .limit(10)
            .all()
        )
        pruning_records = (
            PruningRecord.query.filter_by(farm_id=farm.id)
            .order_by(PruningRecord.date.desc())
            .limit(5)
            .all()
        )
        total_kilos = farm.total_kilos

        cutoff = date.today() - timedelta(days=30)
        last_30 = (
            PluckingRecord.query.filter(PluckingRecord.farm_id == farm.id, PluckingRecord.date >= cutoff)
            .order_by(PluckingRecord.date.asc())
            .all()
        )
        last_30_kilos = sum(r.kilos for r in last_30)
        days_with_records = len({r.date for r in last_30}) or 1
        avg_daily = round(last_30_kilos / days_with_records, 1)

        chart_labels = [r.date.strftime("%d %b") for r in last_30]
        chart_values = [r.kilos for r in last_30]

    tools = Tool.query.filter_by(farmer_id=current_user.id).order_by(Tool.purchase_date.desc()).limit(8).all()
    recent_notes = Note.query.filter_by(farmer_id=current_user.id).order_by(Note.created_at.desc()).limit(5).all()

    weather = _get_weather()

    return render_template(
        "dashboard.html",
        farm=farm,
        farms=farms,
        plucking_records=plucking_records,
        pruning_records=pruning_records,
        tools=tools,
        recent_notes=recent_notes,
        total_kilos=total_kilos,
        avg_daily=avg_daily,
        last_30_kilos=last_30_kilos,
        chart_labels=chart_labels,
        chart_values=chart_values,
        weather=weather,
        total_bushes=current_user.total_bushes,
        today=date.today().isoformat(),
    )


# ---------- Farms ----------

@main_bp.route("/farms/add", methods=["POST"])
@login_required
def add_farm():
    farm_number = request.form.get("farm_number", "").strip()
    location = request.form.get("location", "").strip()
    approx_bushes = request.form.get("approx_bushes", type=int) or 0
    acreage = request.form.get("acreage", type=float)

    if not farm_number:
        flash("Farm number is required.", "error")
        return redirect(url_for("main.dashboard"))

    farm = Farm(
        farmer_id=current_user.id,
        farm_number=farm_number,
        location=location,
        approx_bushes=approx_bushes,
        acreage=acreage,
    )
    db.session.add(farm)
    db.session.commit()
    flash(f"Farm {farm_number} added.", "success")
    return redirect(url_for("main.dashboard", farm_id=farm.id))


@main_bp.route("/farms/<int:farm_id>/update", methods=["POST"])
@login_required
def update_farm(farm_id):
    farm = Farm.query.filter_by(id=farm_id, farmer_id=current_user.id).first_or_404()
    farm.approx_bushes = request.form.get("approx_bushes", type=int) or farm.approx_bushes
    farm.location = request.form.get("location", farm.location)
    acreage = request.form.get("acreage", type=float)
    if acreage is not None:
        farm.acreage = acreage
    db.session.commit()
    flash("Farm details updated.", "success")
    return redirect(url_for("main.dashboard", farm_id=farm.id))


# ---------- Plucking ----------

@main_bp.route("/plucking/add", methods=["POST"])
@login_required
def add_plucking():
    farm_id = request.form.get("farm_id", type=int)
    farm = Farm.query.filter_by(id=farm_id, farmer_id=current_user.id).first_or_404()

    rec_date = request.form.get("date") or date.today().isoformat()
    kilos = request.form.get("kilos", type=float)
    pluckers = request.form.get("pluckers_count", type=int)
    notes = request.form.get("notes", "").strip()

    if not kilos or kilos <= 0:
        flash("Enter a valid number of kilos.", "error")
        return redirect(url_for("main.dashboard", farm_id=farm.id))

    record = PluckingRecord(
        farm_id=farm.id,
        date=date.fromisoformat(rec_date),
        kilos=kilos,
        pluckers_count=pluckers,
        notes=notes,
    )
    db.session.add(record)
    db.session.commit()
    flash(f"Recorded {kilos} kg for {rec_date}.", "success")
    return redirect(url_for("main.dashboard", farm_id=farm.id))


@main_bp.route("/plucking/<int:record_id>/delete", methods=["POST"])
@login_required
def delete_plucking(record_id):
    record = PluckingRecord.query.join(Farm).filter(
        PluckingRecord.id == record_id, Farm.farmer_id == current_user.id
    ).first_or_404()
    farm_id = record.farm_id
    db.session.delete(record)
    db.session.commit()
    flash("Plucking record deleted.", "info")
    return redirect(url_for("main.dashboard", farm_id=farm_id))


# ---------- Pruning ----------

@main_bp.route("/pruning/add", methods=["POST"])
@login_required
def add_pruning():
    farm_id = request.form.get("farm_id", type=int)
    farm = Farm.query.filter_by(id=farm_id, farmer_id=current_user.id).first_or_404()

    rec_date = request.form.get("date") or date.today().isoformat()
    bushes_pruned = request.form.get("bushes_pruned", type=int)
    prune_type = request.form.get("prune_type", "").strip()
    notes = request.form.get("notes", "").strip()

    if not bushes_pruned or bushes_pruned <= 0:
        flash("Enter a valid number of bushes pruned.", "error")
        return redirect(url_for("main.dashboard", farm_id=farm.id))

    record = PruningRecord(
        farm_id=farm.id,
        date=date.fromisoformat(rec_date),
        bushes_pruned=bushes_pruned,
        prune_type=prune_type,
        notes=notes,
    )
    db.session.add(record)
    db.session.commit()
    flash(f"Recorded pruning of {bushes_pruned} bushes.", "success")
    return redirect(url_for("main.dashboard", farm_id=farm.id))


# ---------- Tools ----------

@main_bp.route("/tools/add", methods=["POST"])
@login_required
def add_tool():
    name = request.form.get("name", "").strip()
    quantity = request.form.get("quantity", type=int) or 1
    cost = request.form.get("cost", type=float)
    purchase_date = request.form.get("purchase_date") or date.today().isoformat()
    status = request.form.get("status", "good")
    notes = request.form.get("notes", "").strip()

    if not name:
        flash("Tool name is required.", "error")
        return redirect(url_for("main.dashboard"))

    tool = Tool(
        farmer_id=current_user.id,
        name=name,
        quantity=quantity,
        cost=cost,
        purchase_date=date.fromisoformat(purchase_date),
        status=status,
        notes=notes,
    )
    db.session.add(tool)
    db.session.commit()
    flash(f"Tool '{name}' added to your inventory.", "success")
    return redirect(url_for("main.dashboard"))


@main_bp.route("/tools/<int:tool_id>/status", methods=["POST"])
@login_required
def update_tool_status(tool_id):
    tool = Tool.query.filter_by(id=tool_id, farmer_id=current_user.id).first_or_404()
    tool.status = request.form.get("status", tool.status)
    db.session.commit()
    return redirect(url_for("main.dashboard"))


# ---------- Notes ----------

@main_bp.route("/notes/add", methods=["POST"])
@login_required
def add_note():
    title = request.form.get("title", "").strip()
    content = request.form.get("content", "").strip()
    farm_id = request.form.get("farm_id", type=int)

    if not content:
        flash("Note cannot be empty.", "error")
        return redirect(url_for("main.dashboard"))

    note = Note(farmer_id=current_user.id, farm_id=farm_id, title=title or "Untitled note", content=content)
    db.session.add(note)
    db.session.commit()
    flash("Note saved.", "success")
    return redirect(url_for("main.dashboard"))


@main_bp.route("/notes/<int:note_id>/delete", methods=["POST"])
@login_required
def delete_note(note_id):
    note = Note.query.filter_by(id=note_id, farmer_id=current_user.id).first_or_404()
    db.session.delete(note)
    db.session.commit()
    return redirect(url_for("main.dashboard"))


# ---------- Data / export ----------

@main_bp.route("/api/chart-data")
@login_required
def chart_data():
    farm = _get_selected_farm()
    if not farm:
        return jsonify({"labels": [], "values": []})

    days = request.args.get("days", 30, type=int)
    cutoff = date.today() - timedelta(days=days)
    records = (
        PluckingRecord.query.filter(PluckingRecord.farm_id == farm.id, PluckingRecord.date >= cutoff)
        .order_by(PluckingRecord.date.asc())
        .all()
    )
    return jsonify({
        "labels": [r.date.strftime("%d %b") for r in records],
        "values": [r.kilos for r in records],
    })


@main_bp.route("/export/plucking.csv")
@login_required
def export_plucking_csv():
    farm = _get_selected_farm()
    if not farm:
        flash("Add a farm first.", "error")
        return redirect(url_for("main.dashboard"))

    records = PluckingRecord.query.filter_by(farm_id=farm.id).order_by(PluckingRecord.date.asc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Date", "Kilos", "Pluckers", "Notes"])
    for r in records:
        writer.writerow([r.date.isoformat(), r.kilos, r.pluckers_count or "", r.notes or ""])

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename=farm_{farm.farm_number}_plucking.csv"},
    )
